package uas_teori_oop_a;

public interface RicaroAlisio_44424_Mobil2{
	public int harga = 120000;
	public String merk = "Agya";
	
	public abstract int cicilan(int jmlbln, int hargaMobil);
}
