package uas_teori_oop_a;
import java.io.*;
public class RicaroAlisio_44424_CekCicilan extends IOException{
	public RicaroAlisio_44424_CekCicilan() {
		super("Pesan Err : Cicilan tidak tersedia");
	}
}
